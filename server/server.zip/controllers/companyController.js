import Company from "../models/Company.js";
import bcrypt from 'bcrypt';
import { v2 as cloudinary } from 'cloudinary';
import generateToken from "../utils/generateToken.js";

// Register a new company
export const registerCompany = async (req, res) => {
    const { name, email, password } = req.body;
    const imageFile = req.file; // Optional now

    if (!name || !email || !password) {
        return res.json({ success: false, message: "Please provide name, email and password" });
    }

    try {
        const companyExists = await Company.findOne({ email });

        if (companyExists) {
            return res.json({ success: false, message: 'Company already registered' });
        }

        const salt = await bcrypt.genSalt(10);
        const hashPassword = await bcrypt.hash(password, salt);

        let imageUrl = 'https://via.placeholder.com/150'; // Default image URL

        // Only upload to cloudinary if an image was provided
        if (imageFile) {
            const imageUpload = await cloudinary.uploader.upload(imageFile.path);
            imageUrl = imageUpload.secure_url;
        }

        const company = await Company.create({
            name,
            email,
            password: hashPassword,
            image: imageUrl
        });

        res.json({
            success: true,
            company: {
                _id: company._id,
                name: company.name,
                email: company.email,
                image: company.image
            },
            token: generateToken(company._id)
        });

    } catch (error) {
        res.json({ success: false, message: error.message });
    }
};